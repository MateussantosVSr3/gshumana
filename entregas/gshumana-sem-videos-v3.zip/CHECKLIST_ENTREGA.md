# Checklist de entrega

## Antes de publicar

- [x] Turma 3ESR, nomes e RMs confirmados em `iot/integrantes.txt`.
- [x] Inserir perfil representativo e síntese exploratória em `docs/pesquisa_de_campo.md`.
- [x] Adicionar imagens públicas referenciadas do Jardim Marquesa em `docs/evidencias/`.
- [x] Adotar Jardim Marquesa como recorte territorial do projeto.
- [x] Executar API, testes e app; adicionar prints reais do Mobile, Swagger/API, Azure e Linux.
- [x] Baixar dados oficiais do INMET e executar todas as células do notebook.
- [x] Salvar o notebook executado e revisar `ml/RELATORIO_ML.md` com as métricas obtidas.

## Links externos obrigatórios

- [x] Repositório criado: https://github.com/MateussantosVSr3/gshumana
- [x] Cadastrar cinco Features e dez Test Cases no Azure Boards, com passos e rastreabilidade.
- [x] Professor `profandre.leite@fiap.com.br` adicionado como Admin no projeto Azure.
- [x] Atualizar o relatório de QA com o link/IDs do Azure e gerar novamente o PDF-base.
- [x] Inserir os prints reais do Azure em `qa/RELATORIO_QA_FINAL.html` e gerar o PDF final.
- [x] Circuito publicado e testado no Wokwi: https://wokwi.com/projects/480451288503952385
- [ ] Gravar vídeos: mobile (até 3 min), IoT (até 4 min), ML (até 5 min), Linux (até 7 min) e pitch geral (até 4 min).
- [ ] Publicar vídeos como “não listado” e inserir os links nos READMEs.

## Pacotes por disciplina

- [x] SOA/Web Services: link do GitHub, Swagger e evidências da API.
- [x] Cybersecurity: ZIP do módulo e prints do indicador gerados; falta apenas eventual vídeo exigido pelo professor.
- [x] C#: API, EF Core, LINQ, documentação e quatro testes xUnit validados; falta apenas o envio do link.
- [ ] ML: `ml/`, `RELATORIO_ML.md` e vídeo.
- [ ] Mobile: código, Ficha, instruções e prints concluídos; falta o vídeo.
- [ ] Operating Systems: scripts, configs e evidências concluídos; falta o vídeo.
- [ ] Physical Computing: link Wokwi, vídeo e `integrantes.txt`.
- [ ] Testing/QA: projeto Azure acessível e `qa/RELATORIO_QA.pdf`.
- [ ] Somente um integrante envia cada tarefa até 19/11/2026 às 23h55.
